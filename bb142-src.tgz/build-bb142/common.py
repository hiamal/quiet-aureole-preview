import re,os,html,shutil,sys,base64
BASE='/workspace/jobs/quantum-hypnosis-strategic-psychotherapy'
BOOK='https://quantum-hypnosis-and-strategic-psychotherapy.au3.cliniko.com/bookings'
SITE='https://www.quantumhypnosisstrategicpsychotherapy.com'
VARS={'@@BOOK@@':BOOK,'@@TEL@@':'tel:+61428099997','@@TELTXT@@':'0428 099 997','@@MAIL@@':'mailto:psychotherapy@qhsp.net','@@MAILTXT@@':'psychotherapy@qhsp.net',
'@@CONTACT@@':SITE+'/contact','@@ABOUT@@':SITE+'/about','@@SERVICES@@':SITE+'/services','@@FB@@':'https://www.facebook.com/quantumevolutionprocess','@@IG@@':'https://www.instagram.com/quantum.integration/','@@SITE@@':SITE}
SERV=[
("Strategic Psychotherapy","Designed to achieve targeted goals within a relatively short period. Strategic psychotherapy aims to create practical solutions to problems, enhance communication, and foster positive change.","stones.jpg"),
("Clinical Hypnotherapy","Committed to guiding you through a personalized journey of self-discovery, growth, and positive change to help you achieve your desired outcomes efficiently and effectively.","mind.jpg"),
("Quantum Processes","Designed to address physical, emotional, and energetic imbalances, unlocking your body's innate ability to heal itself and promoting harmony in all aspects of your life.","orb-hand.jpg"),
("Law of Attraction and Empowerment Coach","By understanding and applying the Law of Attraction, clients can shift their mindset, attract abundance, and manifest their goals, while also developing the inner strength and confidence to navigate life's challenges.","sunrise-meditator.jpg"),
("Quantum Release and Transformation","Timeline Process is a powerful healing modality designed to help you release deep-rooted trauma, anxiety, negative emotions, and limiting beliefs that no longer serve you.","mountains.jpg"),
("Quantum Hypnobreathwork","A powerful practice that combines breathwork, hypnosis, and quantum healing to release stored trauma and create deep emotional transformation.","breathwork.jpg"),
("Quantum Past Life Regression","A powerful, transformative process that allows you to access and explore past lives, uncovering deep-rooted patterns, unresolved emotions, and karmic ties that influence your current life.","hands.jpg"),
("Integrated Strategic Psychotherapy & Clinical Hypnotherapy","Blends strategic psychotherapy with clinical hypnotherapy, tailoring her interventions to meet each client's unique needs and goals.","green-light.jpg"),
]
PROCS=[("Quantum Integration Technique","Uses Hypno, NLP and Healing to take you into the Quantum Realm to start living the life you desire."),("Quantum Healing Technique","Takes you on a journey through your body healing every system within your body."),("Quantum Purification Process","Takes you up to the seventh dimension to remove toxins from your body using crystalline energy."),("Quantum Pain Release","Removes pain from the body instantly, by accessing a healthy version of yourself from the Quantum field."),("Quantum Chakra Balance","Clears out the lower chakras, balancing them and bringing balance throughout the body.")]
EXPERT=["Trauma","Pain Release","Healing","Anxiety","Depression","Procrastination","Law of Attraction"]
QUALS=["Diploma of Clinical Hypnotherapy and Strategic Psychotherapy","Masters in Traditional Hypnotherapy and NLP","BSc in Metaphysical Science","Meditation teacher","Empowerment Coach/Law of Attraction Coach","Healing Touch Practitioner and Medical Intuitive"]
TESTI=[
("Working with Susanne at Quantum Healing Hypnosis has been one of the most transformative and effective therapy experiences I've ever had, after nearly a decade of trying various forms of talk therapy, coaching, etc.","Dr. Laura Herman"),
("From our first session, Susanne created a safe space, and I was blown away that I had noticed results after that first session.","Dr. Laura Herman"),
("My experience with Quantum Healing Hypnosis has absolutely changed my life giving me more confidence, greater clarity, and a positive way forward in life in general.","Karen Bishop"),
("Susanne is highly skilled, professional and incredible at what she does. Working with her is life changing!","Amy"),
("Susanne was wonderful! So many things resolved and healed from my sessions with her. She is a great listener and showed genuine warmth and empathy.","Nadia Monteith"),
("Susanne is fabulous at what she does, her technique and caring manner has helped me to dive deep and feel empowered to be me.","Liz"),
("Within only a few sessions she had helped me identify the behaviours I was running and helped me put in place far more beneficial ones.","Jonathan"),
("Usually, my knee would flare, but all good, nothing happened. So far still going well.","Debs"),
]
BADGES=[("badge-hca.png","Hypnotherapy Council of Australia — Accredited Hypnotherapist",0),("badge-gordian.png","The Gordian Pillars Strategic Psychotherapy — Accredited, LIC #110153",0),("badge-strategic-hyp.png","Strategic Hypnotherapists — License Number 200137",0),("badge-iap.png","The Institute of Applied Psychology",0),("badge-isspa.png","International Strategic Psychotherapists Association",0),("badge-ispa-founding.png","ISPA Founding Member — International Strategic Psychotherapists Association",0),("badge-goah.png","GoAH — Guild of Australian Hypnotherapists",0),("badge-ispa-white.png","ISPA Accredited Practitioner",1)]
ROMAN=['i','ii','iii','iv','v','vi','vii','viii']
def half(w=96):
    from PIL import Image
    im=Image.open(BASE+'/assets-bb142/web/susanne.jpg').convert('L'); h=int(w*im.height/im.width); im=im.resize((w,h),Image.LANCZOS)
    return str(w)+','+str(h)+',\''+base64.b64encode(bytes(im.getdata())).decode()+'\''
def expand(s):
    def sub(kind,fmt):
        o=[]
        if kind=='SERV':
            for i,(t,d,im) in enumerate(SERV): o.append(fmt.format(t=html.escape(t,quote=False),d=html.escape(d,quote=False),im=im,k=i,z='%02d'%(i+1),n=ROMAN[i],N=ROMAN[i].upper(),ON=' on' if i==0 else '',u=BOOK))
        elif kind=='PROCS':
            for i,(t,d) in enumerate(PROCS): o.append(fmt.format(t=t,d=d,k=i,z='%02d'%(i+1)))
        elif kind=='EXPERT':
            for i,t in enumerate(EXPERT): o.append(fmt.format(t=t,k=i,z='%02d'%(i+1)))
        elif kind=='QUALS':
            for i,t in enumerate(QUALS): o.append(fmt.format(t=html.escape(t,quote=False),k=i,z='%02d'%(i+1)))
        elif kind=='BADGES':
            for i,(f,a,inv) in enumerate(BADGES): o.append(fmt.format(f=f,a=html.escape(a),inv=' inv' if inv else '',k=i))
        elif kind.startswith('TESTI'):
            lim=int(kind[5:] or 99)
            for i,(q,n) in enumerate(TESTI[:lim]): o.append(fmt.format(q=html.escape(q,quote=False),n=n,k=i,z='%02d'%(i+1),ON=' on' if i==0 else '',R=['-2','1.5','-1','2','-1.5','1','-2.5','2'][i%8]))
        return ''.join(o)
    s=re.sub(r'\{\{(SERV|PROCS|EXPERT|QUALS|BADGES|TESTI\d*):(.*?)\}\}',lambda m:sub(m.group(1),m.group(2)),s,flags=re.S)
    VARS['@@HALF@@']=half()
    for k,v in VARS.items(): s=s.replace(k,v)
    base=open(f'{BASE}/build-bb142/base.js').read()
    return s.replace('@@BASEJS@@',base)
def build(n):
    src=open(f'{BASE}/build-bb142/opt-{n}.src.html').read()
    out=expand(src)
    d=f'{BASE}/previews-bb142/option-{n}'; os.makedirs(d+'/assets',exist_ok=True)
    open(d+'/index.html','w').write(out)
    used=set(re.findall(r'assets/([A-Za-z0-9_.-]+)',out))
    for f in used:
        p=f'{BASE}/assets-bb142/web/{f}'
        if os.path.exists(p): shutil.copy(p,d+'/assets/'+f)
    # verbatim testimonial check
    src_txt=re.sub(r'\s+',' ',open(f'{BASE}/scrape-bb142/home.txt').read().replace('“','"').replace('”','"').replace('’',"'"))
    bad=[n_ for q,n_ in TESTI if re.sub(r'\s+',' ',q) not in src_txt]
    print('built',n,len(out),'bytes; assets',len(used),'; testimonial mismatches:',bad)
if __name__=='__main__': build(sys.argv[1])
