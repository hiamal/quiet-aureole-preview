#!/bin/bash
cd /workspace/jobs/quantum-hypnosis-strategic-psychotherapy/build-bb142 && python3 common.py $1 && cd ../previews-bb142/option-$1 && python3 /workspace/tools/localize-fonts.py . | tail -1
