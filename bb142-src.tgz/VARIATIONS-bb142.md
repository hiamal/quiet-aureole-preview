# BB-142 Susanne Golding / QHSP: six bold homepage concepts (design only)

Source of truth for copy: live site re-scraped Sat 31 Oct 2026 (scrape-bb142/). All offers, 8 services, 5 Quantum Processes, 7 expertise areas, qualifications, 8 testimonials (verified verbatim by the builder), contact details, Hippocrates quote and Cliniko booking CTA are hers; nothing invented. No client contact, no GHL or DNS changes.

Previously (v1/v2/v3 "quiet aureole") were all soft, serif, purple/gold/pearl refinements. These six are new layouts, palettes, type, hero technology and interactions. Only option 1 keeps her brand palette.

| # | Name | Colour system | Type | Hero | Services | Processes | Testimonials |
|---|------|---------------|------|------|----------|-----------|--------------|
| 1 | Pearl Reliquary | Pearl, royal purple, deep night, gold (her brand palette) | DM Serif Display + Instrument Sans | Canvas gold/purple spiral, oval portrait portal that tilts with the cursor | Plates i to viii accordion with sticky arched image preview | Canvas rose diagram, auto-advancing | Auto carousel with progress ticks |
| 2 | Trance | Ink black, bone, single vermillion | Bricolage Grotesque + Space Mono | Full-bleed WebGL hypnotic spiral (mouse and scroll reactive), blend-difference giant headline | Brutalist table accordion, cursor-following image | Pinned 560vh scroll-scrubbed concentric rings | Pinned scroll-swap |
| 3 | Abyss | Abyssal teal, aqua, foam, coral | Fraunces + Sora | WebGL underwater caustics + bubble canvas, depth gauge | Stacked Layer 01 to 08 bands | Scroll-drawn line with glass cards | Drag / snap rail |
| 4 | Instrument | Paper, cobalt, acid lime, navy (graph-paper grid) | Archivo (variable width) + IBM Plex Mono | Lime highlighter wipes, cursor-reactive canvas ridge plot, duotone portrait | 4x2 spec-sheet cards with 3D tilt | Sticky oscilloscope that gains harmonics per step | 3D card deck (click, swipe, keys) |
| 5 | Fernlight | Cream, fern green, sage, clay, butter | Young Serif + Work Sans | Morphing SVG blob portrait, rotating seal, hand-drawn underline, leaf canvas repelled by cursor | Organic masonry with varied shapes that morph on hover | Flex accordion of 5 coloured panels | Rotated note-card wall |
| 6 | Chakra Aurora | Obsidian with a seven-hue chakra spectrum | Unbounded + Manrope | WebGL aurora shader (cursor reactive), spectrum headline, rotating conic rim portrait card | Pinned horizontal-scroll cards with progress bar (snap rail on mobile) | 3D CSS cylinder carousel (drag, arrows, keys, auto-rotate) | Auto-scrolling glass-card marquee columns |

## Rationale
1. **Pearl Reliquary**: the brand-safe luxury answer. Her purple/gold/pearl, but as a theatrical jewel-box layout rather than the soft v1 to v3 look.
2. **Trance**: hypnosis made literal. A stark black, bone and vermillion editorial look for a confident, modern practitioner.
3. **Abyss**: going under. Deep-water calm that mirrors the subconscious and relaxation.
4. **Instrument**: precision and science. Modern clinical-tech look that signals measurable results (NLP, strategic psychotherapy).
5. **Fernlight**: warm, safe, grounded. Organic shapes and earthy colour for trauma-informed approachability.
6. **Chakra Aurora**: energy and quantum healing. A dark glowing spectrum that fits Quantum Healing, Reiki and Law of Attraction.

All six: mobile-first (checked at 390px, no horizontal scroll), `prefers-reduced-motion` support, entrance choreography, scroll reveals, hover micro-interactions, a cursor-reactive element, and a canvas/WebGL/3D hero or hero element. No libraries, fonts self-hosted.

## Tooling notes
- Claude CLI (`claude -p --model opus`) was rate-limited until about 2am AEDT, so everything was hand-built. Status of any later retry is in PROGRESS-bb142.md.
- Kie was not used (optional, not needed).
- Work was backed up to branch `wip-bb142` of hiamal/quiet-aureole-preview (not deployed) because the box was replaced mid-task.
